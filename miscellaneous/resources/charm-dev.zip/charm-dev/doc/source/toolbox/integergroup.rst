
integergroup
=========================================
.. automodule:: integergroup
    :show-inheritance:
    :members:
    :undoc-members:
