
pairinggroup
=========================================
.. automodule:: pairinggroup
    :show-inheritance:
    :members:
    :undoc-members:
