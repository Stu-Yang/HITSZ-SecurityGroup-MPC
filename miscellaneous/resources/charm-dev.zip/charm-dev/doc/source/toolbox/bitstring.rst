
bitstring
=========================================
.. automodule:: bitstring
    :show-inheritance:
    :members:
    :undoc-members:
