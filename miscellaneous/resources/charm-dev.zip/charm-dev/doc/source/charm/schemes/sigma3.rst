
sigma3
=========================================
.. automodule:: sigma3
    :show-inheritance:
    :members:
    :undoc-members:
